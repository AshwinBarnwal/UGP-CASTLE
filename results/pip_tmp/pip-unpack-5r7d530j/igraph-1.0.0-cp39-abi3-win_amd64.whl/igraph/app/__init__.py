"""User interfaces of igraph"""
