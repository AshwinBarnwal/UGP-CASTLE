"""Registers upstream MLIR dialects used by JAX."""

from collections.abc import Callable, Sequence

from jaxlib.mlir import ir


def register_dialects(arg: ir.DialectRegistry, /, register_pipelines: bool = True) -> None: ...

def enter_multi_threaded_execution(arg: ir.Context, /) -> None: ...

def exit_multi_threaded_execution(arg: ir.Context, /) -> None: ...

def inlined_func_call(callee: ir.Operation, args: Sequence[ir.Value], loc: ir.Location | None = ...) -> list[ir.Value]:
    """
    Makes an inlined call to a function containing a single block with a single return op.
    """

def arith_constant(value: int | float | bool, type: ir.Type, /) -> ir.Value:
    """Creates an arith.constant operation."""

class TracebackToLocationCache:
    def __init__(self, code_to_filename: Callable, frame_limit: int, context: ir.Context | None = None) -> None: ...

    def get(self, traceback: Traceback, /) -> ir.Location: ...
