"""MLIR Python Native Extension"""

from collections.abc import Callable, Sequence
import enum
from typing import TypeVar

from jaxlib.mlir import ir

from jaxlib.mlir._mlir_libs._mlir import (
    ir as ir,
    passmanager as passmanager,
    rewrite as rewrite
)


T = TypeVar("T")

U = TypeVar("U")

class OnExplicitAction(enum.Enum):
    USE_EXPLICIT = 0

    USE_TRACEBACK = 1

class CurrentLocAction(enum.Enum):
    FALLBACK = 0

    NAMELOC_WRAP = 1

class _Globals:
    @property
    def dialect_search_modules(self) -> list[str]: ...

    @dialect_search_modules.setter
    def dialect_search_modules(self, arg: Sequence[str], /) -> None: ...

    def append_dialect_search_prefix(self, module_name: str) -> None: ...

    def _check_dialect_module_loaded(self, dialect_namespace: str) -> bool: ...

    def _register_dialect_impl(self, dialect_namespace: str, dialect_class: object, *, replace: bool = False) -> None:
        """Testing hook for directly registering a dialect"""

    def _register_operation_impl(self, operation_name: str, operation_class: object, *, replace: bool = False) -> None:
        """Testing hook for directly registering an operation"""

    def loc_tracebacks_enabled(self) -> bool: ...

    def set_loc_tracebacks_enabled(self, arg: bool, /) -> None: ...

    def loc_tracebacks_frame_limit(self) -> int: ...

    def set_loc_tracebacks_frame_limit(self, arg: int | None, /) -> None: ...

    def register_traceback_file_inclusion(self, arg: str, /) -> None: ...

    def register_traceback_file_exclusion(self, arg: str, /) -> None: ...

    def traceback_action_on_explicit_loc(self) -> OnExplicitAction: ...

    def set_traceback_action_on_explicit_loc(self, arg: OnExplicitAction, /) -> None: ...

    def traceback_action_on_current_loc(self) -> CurrentLocAction: ...

    def set_traceback_action_on_current_loc(self, arg: CurrentLocAction, /) -> None: ...

globals: _Globals = ...

def register_dialect(dialect_class: type) -> type:
    """Class decorator for registering a custom Dialect wrapper"""

def register_operation(dialect_class: type, *, replace: bool = False) -> Callable[[type[T]], type[T]]:
    """
    Produce a class decorator for registering an Operation class as part of a dialect
    """

def register_op_adaptor(op_class: type, *, replace: bool = False) -> Callable[[type[T]], type[T]]:
    """
    Produce a class decorator for registering an OpAdaptor class for an operation.
    """

def register_type_caster(typeid: ir.TypeID, *, replace: bool = False) -> Callable[[Callable[[T], U]], Callable[[T], U]]:
    """Register a type caster for casting MLIR types to custom user types."""

def register_value_caster(typeid: ir.TypeID, *, replace: bool = False) -> Callable[[Callable[[T], U]], Callable[[T], U]]:
    """Register a value caster for casting MLIR values to custom user values."""
