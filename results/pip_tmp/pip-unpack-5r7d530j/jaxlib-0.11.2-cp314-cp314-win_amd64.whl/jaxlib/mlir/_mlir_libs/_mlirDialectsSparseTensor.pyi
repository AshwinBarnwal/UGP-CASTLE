"""MLIR SparseTensor dialect."""

from collections.abc import Sequence
import enum
from typing import Final

from jaxlib.mlir import ir

import jaxlib.jaxlib.mlir.ir


class LevelFormat(enum.IntFlag):
    _boundary_: enum.FlagBoundary = enum.FlagBoundary.KEEP

    _flag_mask_: int = 3997696

    _singles_mask_: int = 3997696

    _all_bits_: int = 8388607

    _inverted_: None = None

    __str__ = __repr__

    def __repr__(self, /):
        """Return repr(self)."""

    dense = 65536

    n_out_of_m = 2097152

    compressed = 262144

    singleton = 524288

    loose_compressed = 1048576

class LevelProperty(enum.Enum):
    non_ordered = 2

    non_unique = 1

    soa = 4

class EncodingAttr(jaxlib.ir.Attribute):
    def __init__(self, cast_from_attr: jaxlib.ir.Attribute) -> None: ...

    @property
    def type(self) -> jaxlib.ir.Type: ...

    static_typeid: Final[jaxlib.ir.TypeID] = ...
    """(arg: object, /) -> jaxlib.ir.TypeID"""

    @property
    def typeid(self) -> jaxlib.ir.TypeID: ...

    def __repr__(self) -> str: ...

    attr_name: Final[str] = ...
    """(arg: object, /) -> str"""

    @staticmethod
    def get(lvl_types: Sequence[int], dim_to_lvl: jaxlib.ir.AffineMap | None, lvl_to_dim: jaxlib.ir.AffineMap | None, pos_width: int, crd_width: int, explicit_val: jaxlib.ir.Attribute | None = None, implicit_val: jaxlib.ir.Attribute | None = None, context: ir.Context | None = None) -> EncodingAttr:
        """Gets a sparse_tensor.encoding from parameters."""

    @staticmethod
    def build_level_type(lvl_fmt: LevelFormat, properties: Sequence[LevelProperty] = [], n: int = 0, m: int = 0) -> int:
        """Builds a sparse_tensor.encoding.level_type from parameters."""

    @property
    def lvl_types(self) -> list[int]: ...

    @property
    def dim_to_lvl(self) -> jaxlib.ir.AffineMap | None: ...

    @property
    def lvl_to_dim(self) -> jaxlib.ir.AffineMap | None: ...

    @property
    def pos_width(self) -> int: ...

    @property
    def crd_width(self) -> int: ...

    @property
    def explicit_val(self) -> jaxlib.ir.Attribute | None: ...

    @property
    def implicit_val(self) -> jaxlib.ir.Attribute | None: ...

    @property
    def structured_n(self) -> int: ...

    @property
    def structured_m(self) -> int: ...

    @property
    def lvl_formats_enum(self) -> list[LevelFormat]: ...
