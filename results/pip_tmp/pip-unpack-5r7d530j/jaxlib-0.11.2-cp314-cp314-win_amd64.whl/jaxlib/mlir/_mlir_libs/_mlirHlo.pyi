"""mlir-hlo main python extension"""

from typing import Self

from collections.abc import Sequence

from jaxlib.mlir import ir

import jaxlib.jaxlib.mlir.ir


def register_mhlo_dialect(context: ir.Context, load: bool = True) -> None: ...

def register_mhlo_passes() -> None: ...

class TokenType(jaxlib.ir.Type):
    @staticmethod
    def isinstance(other_type: ir.Type) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, context: ir.Context | None = None) -> Self:
        """Creates a Token type."""

class ScatterDimensionNumbers(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, update_window_dims: Sequence[int], inserted_window_dims: Sequence[int], input_batching_dims: Sequence[int], scatter_indices_batching_dims: Sequence[int], scattered_dims_to_operand_dims: Sequence[int], index_vector_dim: int, context: ir.Context | None = None) -> Self:
        """
        Creates a ScatterDimensionNumbers with the given dimension configuration.
        """

    @property
    def update_window_dims(self) -> list[int]: ...

    @property
    def inserted_window_dims(self) -> list[int]: ...

    @property
    def input_batching_dims(self) -> list[int]: ...

    @property
    def scatter_indices_batching_dims(self) -> list[int]: ...

    @property
    def scattered_dims_to_operand_dims(self) -> list[int]: ...

    @property
    def index_vector_dim(self) -> int: ...

class GatherDimensionNumbers(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, offset_dims: Sequence[int], collapsed_slice_dims: Sequence[int], operand_batching_dims: Sequence[int], start_indices_batching_dims: Sequence[int], start_index_map: Sequence[int], index_vector_dim: int, context: ir.Context | None = None) -> Self:
        """
        Creates a GatherDimensionNumbers attribute with the given dimension configuration.
        """

    @property
    def offset_dims(self) -> list[int]: ...

    @property
    def collapsed_slice_dims(self) -> list[int]: ...

    @property
    def operand_batching_dims(self) -> list[int]: ...

    @property
    def start_indices_batching_dims(self) -> list[int]: ...

    @property
    def start_index_map(self) -> list[int]: ...

    @property
    def index_vector_dim(self) -> int: ...

class DotDimensionNumbers(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, lhs_batching_dimensions: Sequence[int], rhs_batching_dimensions: Sequence[int], lhs_contracting_dimensions: Sequence[int], rhs_contracting_dimensions: Sequence[int], context: ir.Context | None = None) -> Self:
        """
        Creates a DotDimensionNumbers attribute with the given dimension configuration.
        """

    @property
    def lhs_batching_dimensions(self) -> list[int]: ...

    @property
    def rhs_batching_dimensions(self) -> list[int]: ...

    @property
    def lhs_contracting_dimensions(self) -> list[int]: ...

    @property
    def rhs_contracting_dimensions(self) -> list[int]: ...

class ConvDimensionNumbers(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, input_batch_dimension: int, input_feature_dimension: int, input_spatial_dimensions: Sequence[int], kernel_input_feature_dimension: int, kernel_output_feature_dimension: int, kernel_spatial_dimensions: Sequence[int], output_batch_dimension: int, output_feature_dimension: int, output_spatial_dimensions: Sequence[int], ctx: ir.Context | None = None) -> Self:
        """
        Creates a ConvDimensionNumbers attribute with the given dimension configuration.
        """

    @property
    def input_batch_dimension(self) -> int: ...

    @property
    def input_feature_dimension(self) -> int: ...

    @property
    def input_spatial_dimensions(self) -> list[int]: ...

    @property
    def kernel_input_feature_dimension(self) -> int: ...

    @property
    def kernel_output_feature_dimension(self) -> int: ...

    @property
    def kernel_spatial_dimensions(self) -> list[int]: ...

    @property
    def output_batch_dimension(self) -> int: ...

    @property
    def output_feature_dimension(self) -> int: ...

    @property
    def output_spatial_dimensions(self) -> list[int]: ...

class OutputOperandAlias(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, output_tuple_indices: Sequence[int], operand_index: int, operand_tuple_indices: Sequence[int], ctx: ir.Context | None = None) -> Self:
        """Creates a OutputOperandAlias attribute with the given tuple index."""

    @property
    def output_tuple_indices(self) -> list[int]: ...

    @property
    def operand_index(self) -> int: ...

    @property
    def operand_tuple_indices(self) -> list[int]: ...

class ComparisonDirectionAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a ComparisonDirection attribute with the given value."""

    @property
    def value(self) -> str: ...

class ComparisonTypeAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a ComparisonType attribute with the given value."""

    @property
    def value(self) -> str: ...

class PrecisionAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a Precision attribute with the given value."""

    @property
    def value(self) -> str: ...

class FftTypeAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a FftType attribute with the given value."""

    @property
    def value(self) -> str: ...

class DequantizeModeAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a DequantizeMode attribute with the given value."""

    @property
    def value(self) -> str: ...

class TransposeAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a Transpose attribute with the given value."""

    @property
    def value(self) -> str: ...

class FusionKindAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a FusionKind attribute with the given value."""

    @property
    def value(self) -> str: ...

class RngDistributionAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a RngDistribution attribute with the given value."""

    @property
    def value(self) -> str: ...

class RngAlgorithmAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a RngAlgorithm attribute with the given value."""

    @property
    def value(self) -> str: ...

class ChannelHandle(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, handle: int, type: int, context: ir.Context | None = None) -> Self:
        """Creates a ChannelHandle attribute."""

    @property
    def handle(self) -> int: ...

    @property
    def channel_type(self) -> int: ...

class TypeExtensions(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, bounds: Sequence[int], context: ir.Context | None = None) -> Self:
        """Creates a TypeExtensions with the given bounds."""

    @property
    def bounds(self) -> list[int]: ...
