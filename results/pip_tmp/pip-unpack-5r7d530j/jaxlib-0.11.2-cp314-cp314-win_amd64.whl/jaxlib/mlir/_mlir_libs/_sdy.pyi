"""SDY main Python extension"""

from typing import Self

from collections.abc import Sequence
import enum

import mlir
from jaxlib.mlir import ir

import jaxlib.jaxlib.mlir.ir


def register_dialect(context: ir.Context, load: bool = True) -> None: ...

class CompatibilityRequirement(enum.Enum):
    NONE = 0

    WEEK_4 = 1

    WEEK_12 = 2

    MAX = 3

def get_version_from_compatibility_requirement(requirement: CompatibilityRequirement) -> str: ...

class MeshAxisAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, name: str, size: int, context: ir.Context | None = None) -> Self:
        """Creates a MeshAxisAttr with the given axis name and size."""

    @property
    def name(self) -> str: ...

    @property
    def size(self) -> int: ...

class MeshAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, mesh_axes: Sequence[ir.Attribute], device_ids: Sequence[int] = [], context: ir.Context | None = None) -> Self:
        """Creates a MeshAttr with the given mesh axes."""

    @property
    def device_ids(self) -> list[int]: ...

    @property
    def axes(self) -> list[ir.Attribute]: ...

class SubAxisInfoAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, pre_size: int, size: int, context: ir.Context | None = None) -> Self:
        """Creates a SubAxisInfoAttr with the given pre-size and size."""

    @property
    def pre_size(self) -> int: ...

    @property
    def size(self) -> int: ...

class AxisRefAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, name: str, sub_axis_info: ir.Attribute | None = None, context: ir.Context | None = None) -> Self:
        """Creates an AxisRefAttr with the given name and SubAxisInfoAttr."""

    @property
    def name(self) -> str: ...

    @property
    def sub_axis_info(self) -> ir.Attribute | None: ...

class DimensionShardingAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, axes: Sequence[ir.Attribute], is_closed: bool, priority: int | None = None, context: ir.Context | None = None) -> Self:
        """
        Creates a DimensionShardingAttr with the given axes, whether it's closed, and priority.
        """

    @property
    def axes(self) -> list[ir.Attribute]: ...

    @property
    def is_closed(self) -> bool: ...

    @property
    def priority(self) -> int | None: ...

class TensorShardingAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, mesh_or_ref: str | ir.Attribute, dimension_shardings: Sequence[ir.Attribute], replicated_axes: Sequence[ir.Attribute] = [], unreduced_axes: Sequence[ir.Attribute] = [], reduction_op: mlir.dialects.sdy.ReductionOp | None = 0, context: ir.Context | None = None) -> Self:
        """
        Creates a TensorShardingAttr with either an inlined mesh or mesh name, dimension shardings, and replicated axes.
        """

    @property
    def mesh_or_ref(self) -> ir.Attribute: ...

    @property
    def dimension_shardings(self) -> list[ir.Attribute]: ...

    @property
    def replicated_axes(self) -> list[ir.Attribute]: ...

    @property
    def unreduced_axes(self) -> list[ir.Attribute]: ...

    @property
    def reduction_op(self) -> mlir.dialects.sdy.ReductionOp: ...

class TensorShardingPerValueAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, shardings: Sequence[ir.Attribute], context: ir.Context | None = None) -> Self:
        """Creates a TensorShardingPerValueAttr with the tensor shardings."""

    @property
    def shardings(self) -> list[ir.Attribute]: ...

class DimMappingAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, factor_indices: Sequence[int], context: ir.Context | None = None) -> Self:
        """Creates a DimMappingAttr with the factor indices."""

    @property
    def factor_indices(self) -> list[int]: ...

class TensorMappingAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, dim_mappings: Sequence[ir.Attribute], context: ir.Context | None = None) -> Self:
        """Creates a TensorMappingAttr with the dim mappings."""

    @property
    def dim_mappings(self) -> list[ir.Attribute]: ...

    @property
    def rank(self) -> int: ...

class OpShardingRuleAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, factor_sizes: Sequence[int], operand_mappings: Sequence[ir.Attribute], result_mappings: Sequence[ir.Attribute], reduction_factors: Sequence[int] = [], need_replication_factors: Sequence[int] = [], permutation_factors: Sequence[int] = [], blocked_propagation_factors: Sequence[int] = [], is_custom: bool = False, context: ir.Context | None = None) -> Self:
        """
        Creates a OpShardingRuleAttr with the factor sizes and mappings for operands and results.
        """

    @property
    def is_custom(self) -> bool: ...

    @property
    def factor_sizes(self) -> list[int]: ...

    @property
    def operand_mappings(self) -> list[ir.Attribute]: ...

    @property
    def result_mappings(self) -> list[ir.Attribute]: ...

    @property
    def reduction_factors(self) -> list[int]: ...

    @property
    def need_replication_factors(self) -> list[int]: ...

    @property
    def permutation_factors(self) -> list[int]: ...

    @property
    def blocked_propagation_factors(self) -> list[int]: ...

class ManualAxesAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, manual_axes: Sequence[ir.Attribute], context: ir.Context | None = None) -> Self:
        """Creates a ManualAxesAttr with the given manual axes."""

    def __getitem__(self, arg: int, /) -> str: ...

    def __len__(self) -> int: ...
