"""stablehlo main python extension"""

from collections.abc import Sequence
import enum
from typing import overload, Self

from jaxlib.mlir import ir

import jaxlib.jaxlib.mlir.ir


def register_dialect(context: ir.Context, load: bool = True) -> None: ...

def register_interpreter_dialect(context: ir.Context, load: bool = True) -> None: ...

def register_stablehlo_passes() -> None: ...

class TokenType(jaxlib.ir.Type):
    @staticmethod
    def isinstance(other_type: ir.Type) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, context: ir.Context | None = None) -> Self:
        """Creates a Token type."""

class FutureType(jaxlib.ir.Type):
    @staticmethod
    def isinstance(other_type: ir.Type) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, types: Sequence[ir.Type], context: ir.Context | None = None) -> Self:
        """Creates a Future type."""

    @property
    def types(self) -> list[ir.Type]: ...

class ScatterDimensionNumbers(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, update_window_dims: Sequence[int], inserted_window_dims: Sequence[int], input_batching_dims: Sequence[int], scatter_indices_batching_dims: Sequence[int], scattered_dims_to_operand_dims: Sequence[int], index_vector_dim: int, context: ir.Context | None = None) -> Self:
        """
        Creates a ScatterDimensionNumbers with the given dimension configuration.
        """

    @property
    def update_window_dims(self) -> list[int]: ...

    @property
    def inserted_window_dims(self) -> list[int]: ...

    @property
    def input_batching_dims(self) -> list[int]: ...

    @property
    def scatter_indices_batching_dims(self) -> list[int]: ...

    @property
    def scattered_dims_to_operand_dims(self) -> list[int]: ...

    @property
    def index_vector_dim(self) -> int: ...

class GatherDimensionNumbers(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, offset_dims: Sequence[int], collapsed_slice_dims: Sequence[int], operand_batching_dims: Sequence[int], start_indices_batching_dims: Sequence[int], start_index_map: Sequence[int], index_vector_dim: int, context: ir.Context | None = None) -> Self:
        """
        Creates a GatherDimensionNumbers attribute with the given dimension configuration.
        """

    @property
    def offset_dims(self) -> list[int]: ...

    @property
    def collapsed_slice_dims(self) -> list[int]: ...

    @property
    def operand_batching_dims(self) -> list[int]: ...

    @property
    def start_indices_batching_dims(self) -> list[int]: ...

    @property
    def start_index_map(self) -> list[int]: ...

    @property
    def index_vector_dim(self) -> int: ...

class DotAlgorithm(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, lhs_precision_type: ir.Type, rhs_precision_type: ir.Type, accumulation_type: ir.Type, lhs_component_count: int, rhs_component_count: int, num_primitive_operations: int, allow_imprecise_accumulation: bool, ctx: ir.Context | None = None) -> Self:
        """
        Creates a DotAlgorithm attribute with the given dimension configuration.
        """

    @property
    def lhs_precision_type(self) -> ir.Type: ...

    @property
    def rhs_precision_type(self) -> ir.Type: ...

    @property
    def accumulation_type(self) -> ir.Type: ...

    @property
    def lhs_component_count(self) -> int: ...

    @property
    def rhs_component_count(self) -> int: ...

    @property
    def num_primitive_operations(self) -> int: ...

    @property
    def allow_imprecise_accumulation(self) -> bool: ...

class DotDimensionNumbers(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, lhs_batching_dimensions: Sequence[int], rhs_batching_dimensions: Sequence[int], lhs_contracting_dimensions: Sequence[int], rhs_contracting_dimensions: Sequence[int], context: ir.Context | None = None) -> Self:
        """
        Creates a DotDimensionNumbers attribute with the given dimension configuration.
        """

    @property
    def lhs_batching_dimensions(self) -> list[int]: ...

    @property
    def rhs_batching_dimensions(self) -> list[int]: ...

    @property
    def lhs_contracting_dimensions(self) -> list[int]: ...

    @property
    def rhs_contracting_dimensions(self) -> list[int]: ...

class ConvDimensionNumbers(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, input_batch_dimension: int, input_feature_dimension: int, input_spatial_dimensions: Sequence[int], kernel_input_feature_dimension: int, kernel_output_feature_dimension: int, kernel_spatial_dimensions: Sequence[int], output_batch_dimension: int, output_feature_dimension: int, output_spatial_dimensions: Sequence[int], ctx: ir.Context | None = None) -> Self:
        """
        Creates a ConvDimensionNumbers attribute with the given dimension configuration.
        """

    @property
    def input_batch_dimension(self) -> int: ...

    @property
    def input_feature_dimension(self) -> int: ...

    @property
    def input_spatial_dimensions(self) -> list[int]: ...

    @property
    def kernel_input_feature_dimension(self) -> int: ...

    @property
    def kernel_output_feature_dimension(self) -> int: ...

    @property
    def kernel_spatial_dimensions(self) -> list[int]: ...

    @property
    def output_batch_dimension(self) -> int: ...

    @property
    def output_feature_dimension(self) -> int: ...

    @property
    def output_spatial_dimensions(self) -> list[int]: ...

class OutputOperandAlias(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, output_tuple_indices: Sequence[int], operand_index: int, operand_tuple_indices: Sequence[int], ctx: ir.Context | None = None) -> Self:
        """Creates a OutputOperandAlias attribute with the given tuple index."""

    @property
    def output_tuple_indices(self) -> list[int]: ...

    @property
    def operand_index(self) -> int: ...

    @property
    def operand_tuple_indices(self) -> list[int]: ...

class ComparisonDirectionAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a ComparisonDirection attribute with the given value."""

    @property
    def value(self) -> str: ...

class ComparisonTypeAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a ComparisonType attribute with the given value."""

    @property
    def value(self) -> str: ...

class PrecisionAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a Precision attribute with the given value."""

    @property
    def value(self) -> str: ...

class FftTypeAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a FftType attribute with the given value."""

    @property
    def value(self) -> str: ...

class TransposeAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a Transpose attribute with the given value."""

    @property
    def value(self) -> str: ...

class RngDistributionAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a RngDistribution attribute with the given value."""

    @property
    def value(self) -> str: ...

class RngAlgorithmAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a RngAlgorithm attribute with the given value."""

    @property
    def value(self) -> str: ...

class ChannelHandle(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, handle: int, type: int, context: ir.Context | None = None) -> Self:
        """Creates a ChannelHandle attribute."""

    @property
    def handle(self) -> int: ...

    @property
    def channel_type(self) -> int: ...

class TypeExtensions(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, bounds: Sequence[int], context: ir.Context | None = None) -> Self:
        """Creates a TypeExtensions with the given bounds."""

    @property
    def bounds(self) -> list[int]: ...

class ResultAccuracyAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, atol: float, rtol: float, ulps: int, mode: str, context: ir.Context | None = None) -> Self:
        """Creates a ResultAccuracyAttr with the given values."""

    @property
    def atol(self) -> float: ...

    @property
    def rtol(self) -> float: ...

    @property
    def ulps(self) -> int: ...

    @property
    def mode(self) -> str: ...

class SubAxisInfoAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, pre_size: int, size: int, context: ir.Context | None = None) -> Self:
        """Creates a SubAxisInfoAttr with the given pre_size and size."""

    @property
    def pre_size(self) -> int: ...

    @property
    def size(self) -> int: ...

class AxisRefAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, name: str, sub_axis_info: ir.Attribute | None = None, context: ir.Context | None = None) -> Self:
        """Creates an AxisRefAttr with the given name and optional sub_axis_info."""

    @property
    def name(self) -> str: ...

    @property
    def sub_axis_info(self) -> object: ...

class ReplicaGroupMeshAxesAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, mesh: ir.Attribute, axes: ir.Attribute, context: ir.Context | None = None) -> Self:
        """Creates a ReplicaGroupMeshAxesAttr with the given mesh and axes."""

    @property
    def mesh(self) -> ir.Attribute: ...

    @property
    def axes(self) -> ir.Attribute: ...

class MeshAxisAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, name: str, size: int, context: ir.Context | None = None) -> Self:
        """Creates a MeshAxisAttr with the given name and size."""

    @property
    def name(self) -> str: ...

    @property
    def size(self) -> int: ...

class MeshAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, axes: ir.Attribute, device_ids: ir.Attribute | None = None, context: ir.Context | None = None) -> Self:
        """Creates a MeshAttr with the given axes and optional device_ids."""

    @property
    def axes(self) -> ir.Attribute: ...

    @property
    def device_ids(self) -> object: ...

class ResultAccuracyModeAttr(jaxlib.ir.Attribute):
    @staticmethod
    def isinstance(other_attribute: ir.Attribute) -> bool: ...

    def __repr__(self) -> str: ...

    @classmethod
    def get(cls, value: str, context: ir.Context | None = None) -> Self:
        """Creates a ResultAccuracyModeAttr with the given values."""

    @property
    def value(self) -> str: ...

def get_api_version() -> int: ...

def get_smaller_version(version1: str, version2: str) -> str: ...

def get_current_version() -> str: ...

def get_minimum_version() -> str: ...

@overload
def serialize_portable_artifact_str(module_str: str, target_version: str) -> bytes: ...

@overload
def serialize_portable_artifact_str(module_str: bytes, target_version: str) -> bytes: ...

@overload
def deserialize_portable_artifact_str(artifact_str: str) -> bytes: ...

@overload
def deserialize_portable_artifact_str(artifact_str: bytes) -> bytes: ...

class StablehloCompatibilityRequirement(enum.Enum):
    NONE = 0

    WEEK_4 = 1

    WEEK_12 = 2

    MAX = 3

def get_version_from_compatibility_requirement(requirement: StablehloCompatibilityRequirement) -> str: ...

def serialize_portable_artifact(module: ir.Module, target: str, allow_other_dialects: bool = False) -> bytes: ...

@overload
def deserialize_portable_artifact(context: ir.Context, artifact: str) -> ir.Module: ...

@overload
def deserialize_portable_artifact(context: ir.Context, artifact: bytes) -> ir.Module: ...

def eval_module(module: ir.Module, args: Sequence[ir.Attribute], probe_instrumentation_dir: str = '') -> list[ir.Attribute]: ...
